package precios;

public class ProductPrices {
    public static void main(String[] args) {
        double[] prices = new double[15];

        // Asignar precios (ejemplo)
        for (int i = 0; i < prices.length; i++) {
            prices[i] = 10.0 + (i * 2.5);
        }

        System.out.println("Precios de los 15 productos:");
        for (int i = 0; i < prices.length; i++) {
            System.out.println("Producto " + (i + 1) + ": $" + String.format("%.2f", prices[i]));
        }
    }
}

