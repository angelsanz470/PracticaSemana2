package estudiantes;

public class Student {
    String firstName;
    String lastName;
    double gradeAverage;

    public Student(String firstName, String lastName, double gradeAverage) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gradeAverage = gradeAverage;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public double getGradeAverage() {
        return gradeAverage;
    }

    public String getStudentInfo() {
        return "Nombre: " + firstName + ", Apellido: " + lastName + ", Promedio: " + String.format("%.2f", gradeAverage);
    }

    @Override
    public String toString() {
        return firstName + " " + lastName + " (Calificación Promedio: " + String.format("%.2f", gradeAverage) + ")";
    }
}


