package estudiantes;

import java.util.Scanner;

public class StudentData {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Student[] students = new Student[10];

        System.out.println("Registro de 10 estudiantes:");
        for (int i = 0; i < students.length; i++) {
            System.out.println("\nEstudiante #" + (i + 1) + ":");
            System.out.print("Nombres: ");
            String firstName = scanner.nextLine();
            System.out.print("Apellidos: ");
            String lastName = scanner.nextLine();
            double average;
            while (true) {
                System.out.print("Calificación Promedio (0-100): ");
                if (scanner.hasNextDouble()) {
                    average = scanner.nextDouble();
                    if (average >= 0 && average <= 100) {
                        break;
                    } else {
                        System.out.println("El promedio debe estar entre 0 y 100.");
                    }
                } else {
                    System.out.println("Entrada inválida. Por favor, ingrese un número.");
                    scanner.next(); // Consumir la entrada inválida
                }
            }
            scanner.nextLine(); // Consumir el salto de línea

            students[i] = new Student(firstName, lastName, average);
        }

        if (students.length == 0) {
            System.out.println("No se registraron estudiantes.");
            return;
        }

        Student highestGradeStudent = students[0];
        Student lowestGradeStudent = students[0];

        for (int i = 1; i < students.length; i++) {
            if (students[i].getGradeAverage() > highestGradeStudent.getGradeAverage()) {
                highestGradeStudent = students[i];
            }
            if (students[i].getGradeAverage() < lowestGradeStudent.getGradeAverage()) {
                lowestGradeStudent = students[i];
            }
        }

        System.out.println("\n--- Resumen de Estudiantes ---");
        System.out.println("Estudiante con la calificación promedio más alta: " + highestGradeStudent.getStudentInfo());
        System.out.println("Estudiante con la calificación promedio más baja: " + lowestGradeStudent.getStudentInfo());

        scanner.close();
    }
}

